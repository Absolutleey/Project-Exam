package project.gunshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import project.gunshop.model.User;


import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User,Long> {


    Optional<User> findByPasswordAndUsername(String password, String username);

    Optional<User> findByUsername(String username);
}
