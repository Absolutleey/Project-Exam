package project.gunshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import project.gunshop.model.enums.GunType;
import project.gunshop.model.Weapon;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface WeaponRepository extends JpaRepository<Weapon, Long> {

    @Query("SELECT SUM(w.price) FROM Weapon w")
    BigDecimal findTotalSum();

    List<Weapon> findAllByType(GunType gunType);

    Optional<Weapon> findWeaponById (Long id);

}
