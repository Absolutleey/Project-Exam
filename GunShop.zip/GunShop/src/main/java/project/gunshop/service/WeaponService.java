package project.gunshop.service;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import project.gunshop.model.enums.GunType;
import project.gunshop.model.Weapon;
import project.gunshop.model.service.WeaponServiceModel;
import project.gunshop.repository.WeaponRepository;
import project.gunshop.model.view.WeaponViewModel;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class WeaponService {

    private final WeaponRepository weaponRepository;
    private final ModelMapper modelMapper;

    public WeaponService(WeaponRepository weaponRepository, ModelMapper modelMapper) {
        this.weaponRepository = weaponRepository;
        this.modelMapper = modelMapper;
    }

    public void add(WeaponServiceModel weaponServiceModel) {

        Weapon weapon = modelMapper.
                map(weaponServiceModel, Weapon.class);

        weaponRepository.save(weapon);
    }


    public BigDecimal getTotalSum() {
        BigDecimal totalSum = new BigDecimal(0);

        totalSum = this.weaponRepository.findTotalSum();

        if (totalSum == null) {
            totalSum = BigDecimal.valueOf(0);
        }
        return totalSum;
    }

    public List<WeaponViewModel> findAllByType(GunType gunType) {

        return weaponRepository.findAllByType(gunType)
                .stream()
                .map(weapon -> modelMapper.map(weapon, WeaponViewModel.class))
                .collect(Collectors.toList());
    }

    public WeaponViewModel findWeaponById(Long id) {

        Optional<Weapon> weapon = this.weaponRepository.findWeaponById(id);

        if (weapon.isEmpty()) {
            return null;
        }

        return this.modelMapper.map(weapon, WeaponViewModel.class);

    }


    public void buyById(Long id) {
        this.weaponRepository.deleteById(id);
    }

    public void buyAll() {
        this.weaponRepository.deleteAll();
    }
}
