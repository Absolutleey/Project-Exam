package project.gunshop.service;

import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import project.gunshop.model.User;

import project.gunshop.model.enums.UserRoleEnum;
import project.gunshop.model.dto.UserRegisterDTO;
import project.gunshop.repository.UserRepository;


@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;



    public UserService(ModelMapper modelMapper, UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }


    public void register(UserRegisterDTO userRegisterDTO) {

        User user = new User();
        user.setUsername(userRegisterDTO.getUsername());
        user.setPassword(passwordEncoder.encode(userRegisterDTO.getPassword()));
        user.setEmail(userRegisterDTO.getEmail());



        if (this.userRepository.count() == 0) {
            user.setUserRole(UserRoleEnum.ADMIN);
        }else {
            user.setUserRole(UserRoleEnum.CUSTOMER);
        }

        this.userRepository.saveAndFlush(user);

    }

    public User findByPasswordAndUsername(String password, String username) {
        return
                this.userRepository.findByPasswordAndUsername(password, username).orElse(null);
    }
}
