package project.gunshop.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Iterator;

public class LoginInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        System.out.println("preHANDLE");
        System.out.println(request.getRequestURI() + " " + request.getMethod());

        Iterator<String> headerNames = request.getHeaderNames().asIterator();
        while (headerNames.hasNext()) {
            String headerName = headerNames.next();
            String headerValue = request.getHeader(headerName);
            System.out.println(headerName + " " + headerValue);
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        System.out.println("postHANDLE");
        if (modelAndView == null){
            return;
        }
        for (String entry : modelAndView.getModel().keySet()) {
            System.out.println(entry + ": " + modelAndView.getModel().get(entry));
        }
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        System.out.println("afterCOMPLETION");
        if (ex != null) {
            ex.printStackTrace();
        }
        response.setStatus(200);
    }
}
