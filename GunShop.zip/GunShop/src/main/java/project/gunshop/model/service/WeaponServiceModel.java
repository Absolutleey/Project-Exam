package project.gunshop.model.service;


import project.gunshop.model.enums.GunType;


import java.math.BigDecimal;
import java.time.LocalDate;

public class WeaponServiceModel {

    private String model;

    private double caliber;

    private LocalDate manufacture;

    private BigDecimal price;

    private GunType type;

    public WeaponServiceModel() {
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getCaliber() {
        return caliber;
    }

    public void setCaliber(double caliber) {
        this.caliber = caliber;
    }

    public LocalDate getManufacture() {
        return manufacture;
    }

    public void setManufacture(LocalDate manufacture) {
        this.manufacture = manufacture;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public GunType getType() {
        return type;
    }

    public void setType(GunType type) {
        this.type = type;
    }
}
