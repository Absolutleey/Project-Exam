package project.gunshop.model.enums;

public enum GunType {
    PISTOL, SHOTGUN, MACHINE_GUN ,RIFLE
}
