package project.gunshop.model.enums;

public enum ColdWeaponType {
    KNIFE, AXE
}
