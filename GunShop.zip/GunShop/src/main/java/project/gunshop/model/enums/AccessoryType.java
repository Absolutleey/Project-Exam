package project.gunshop.model.enums;

public enum AccessoryType {
    HAT, GLOVES, SCARF, GLASSES, BELT, CARTRIDGE_BELT, SOCKS,
}
