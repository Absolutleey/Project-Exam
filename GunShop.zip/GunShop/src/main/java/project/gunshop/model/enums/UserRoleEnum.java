package project.gunshop.model.enums;

public enum UserRoleEnum {
    ADMIN, CUSTOMER
}
