package project.gunshop.model;

import project.gunshop.model.enums.GunType;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "weapons")
public class Weapon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column (nullable = false)
    private String model;

    private double caliber;

    @Column(nullable = false)
    private LocalDate manufacture;

    @Column (nullable = false)
    private BigDecimal price;

    @Enumerated(EnumType.STRING)
    private GunType type;

    @ManyToOne
    private Offer offer;

    public void setId(long id) {
        this.id = id;
    }

    public Offer getOffer() {
        return offer;
    }

    public void setOffer(Offer offer) {
        this.offer = offer;
    }

    public Weapon(){}

    public long getId() {
        return id;
    }

    public Weapon(GunType type) {
        this.type = type;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getCaliber() {
        return caliber;
    }

    public void setCaliber(double caliber) {
        this.caliber = caliber;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public GunType getType() {
        return type;
    }

    public void setType(GunType type) {
        this.type = type;
    }

    public LocalDate getManufacture() {
        return manufacture;
    }

    public void setManufacture(LocalDate manufacture) {
        this.manufacture = manufacture;
    }


}
