package project.gunshop.model.enums;

public enum ClothesSize {
    S, M, L, XL, XXL
}
