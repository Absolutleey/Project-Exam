package project.gunshop.model;

import project.gunshop.model.enums.ClothesSize;
import project.gunshop.model.enums.ClothesType;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "clothes")
public class Clothing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String brand;

    @Column(unique = true, nullable = false, name = "image_url")
    private String imageURL;

    @Column(nullable = false)
    private BigDecimal price;

    @Column(nullable = false, name = "clothes_type")
    private ClothesType clothesType;

    @Column(nullable = false, name = "clothes_size")
    private ClothesSize clothesSize;

    @Column
    private String description;

    @ManyToOne
    private Offer offer;



    public Clothing() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public ClothesType getClothesType() {
        return clothesType;
    }

    public void setClothesType(ClothesType clothesType) {
        this.clothesType = clothesType;
    }

    public ClothesSize getClothesSize() {
        return clothesSize;
    }

    public void setClothesSize(ClothesSize clothesSize) {
        this.clothesSize = clothesSize;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Offer getOffer() {
        return offer;
    }

    public void setOffer(Offer offer) {
        this.offer = offer;
    }
}
