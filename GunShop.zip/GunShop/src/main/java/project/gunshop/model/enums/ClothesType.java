package project.gunshop.model.enums;

public enum ClothesType {
    PANTS, SHIRT, JACKET, TOP
}
