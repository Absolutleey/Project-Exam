package project.gunshop.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "ammunition")
public class Ammo {

    @Id
    @GeneratedValue(generator = "uuid-string")
    @GenericGenerator(name = "uuid-string",
              strategy = "org.hibernate.id.UUIDGenerator")
    private String UUID;

    @Column(nullable = false)
    private String manufacturer;

    @Column(nullable = false)
    private double caliber;

    @Column(nullable = false)
    private BigDecimal price;

    @Column(nullable = false, name = "bullet_weight")
    private double bulletWeight;

    @ManyToOne
    private Offer offer;

    public Ammo() {
    }

    public String getUUID() {
        return UUID;
    }

    public void setUUID(String UUID) {
        this.UUID = UUID;
    }

    public Offer getOffer() {
        return offer;
    }
    public void setOffer(Offer offer) {
        this.offer = offer;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public double getCaliber() {
        return caliber;
    }

    public void setCaliber(double caliber) {
        this.caliber = caliber;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public double getBulletWeight() {
        return bulletWeight;
    }

    public void setBulletWeight(double bulletWeight) {
        this.bulletWeight = bulletWeight;
    }
}
