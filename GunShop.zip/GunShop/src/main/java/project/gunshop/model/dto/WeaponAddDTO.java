package project.gunshop.model.dto;

import org.springframework.format.annotation.DateTimeFormat;
import project.gunshop.model.enums.GunType;

import javax.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDate;

public class WeaponAddDTO {

    @NotBlank
    private String model;

    @Positive
    private double caliber;

    @PastOrPresent
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate manufacture;

    @Positive
    private BigDecimal price;

    @NotNull
    private GunType type;

    public WeaponAddDTO() {
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getCaliber() {
        return caliber;
    }

    public void setCaliber(double caliber) {
        this.caliber = caliber;
    }

    public LocalDate getManufacture() {
        return manufacture;
    }

    public void setManufacture(LocalDate manufacture) {
        this.manufacture = manufacture;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public GunType getType() {
        return type;
    }

    public void setType(GunType type) {
        this.type = type;
    }
}
