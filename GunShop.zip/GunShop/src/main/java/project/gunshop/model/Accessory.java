package project.gunshop.model;

import org.hibernate.annotations.GenericGenerator;
import project.gunshop.model.enums.AccessoryType;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "accessories")
public class Accessory {

    @Id
    @GeneratedValue(generator = "uuid-string")
    @GenericGenerator(name = "uuid-string",
            strategy = "org.hibernate.id.UUIDGenerator")
    private String UUID;

    @Column(nullable = false)
    private BigDecimal price;

    @Column(nullable = false, name = "accessory_type")
    private AccessoryType accessoryType;

    @Column
    private String description;

    @ManyToOne
    private Offer offer;

    public Accessory() {
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Offer getOffer() {
        return offer;
    }

    public void setOffer(Offer offer) {
        this.offer = offer;
    }

    public String getUUID() {
        return UUID;
    }

    public void setUUID(String UUID) {
        this.UUID = UUID;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public AccessoryType getAccessoryType() {
        return accessoryType;
    }

    public void setAccessoryType(AccessoryType accessoryType) {
        this.accessoryType = accessoryType;
    }
}
