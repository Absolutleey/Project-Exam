package project.gunshop.model;

import project.gunshop.model.enums.ColdWeaponType;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "knives_axes")
public class KnifeAndAxe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String manufacturer;

    @Column(nullable = false,name = "blade_length")
    private double bladeLength;

    @Column(nullable = false, name = "handle_length")
    private double handleLength;

    @Column(nullable = false , name = "image_url")
    private String imageURL;

    @Column(nullable = false)
    private BigDecimal price;

    @Column(nullable = false)
    private ColdWeaponType type;

    @Column
    private String description;

    @ManyToOne
    private Offer offer;

    public KnifeAndAxe() {
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Offer getOffer() {
        return offer;
    }

    public void setOffer(Offer offer) {
        this.offer = offer;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public double getBladeLength() {
        return bladeLength;
    }

    public void setBladeLength(double bladeLength) {
        this.bladeLength = bladeLength;
    }

    public double getHandleLength() {
        return handleLength;
    }

    public void setHandleLength(double handleLength) {
        this.handleLength = handleLength;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public ColdWeaponType getType() {
        return type;
    }

    public void setType(ColdWeaponType type) {
        this.type = type;
    }
}
