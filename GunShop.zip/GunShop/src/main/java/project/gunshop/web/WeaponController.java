package project.gunshop.web;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import project.gunshop.model.error.ProductNotFoundException;
import project.gunshop.model.dto.WeaponAddDTO;
import project.gunshop.model.service.WeaponServiceModel;
import project.gunshop.model.view.WeaponViewModel;
import project.gunshop.service.WeaponService;

import javax.validation.Valid;

@Controller
@RequestMapping("/weapon")
public class WeaponController {

    private final ModelMapper mapper;
    private final WeaponService weaponService;

    public WeaponController(ModelMapper mapper, WeaponService weaponService) {
        this.mapper = mapper;
        this.weaponService = weaponService;
    }

    @GetMapping("/add")
    public String weapon(Model model) {
        if (!model.containsAttribute("weaponAddDTO")) {
            model.addAttribute("weaponAddDTO", new WeaponAddDTO());
        }

        return "weapon-add";
    }


    @PostMapping("/add")
    private String addWeapon(@Valid WeaponAddDTO weaponAddDTO,
                             BindingResult bindingResult,
                             RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("weaponAddDTO", weaponAddDTO);
            redirectAttributes.addFlashAttribute("org.springframework.validation.weaponAddDTO", bindingResult);
            return "redirect:add";
        }


        this.weaponService.add(mapper.map(weaponAddDTO, WeaponServiceModel.class));

        return "redirect:add";
    }

    @GetMapping("/find/{id}")
    public String getWeaponById(
            @PathVariable Long id,
            Model model
            ){

        WeaponViewModel weaponById = this.weaponService.findWeaponById(id);

        if (weaponById == null){
            throw new ProductNotFoundException(id);
        }

        model.addAttribute("weapon",weaponById);

        return "find";
    }

    @ExceptionHandler({ProductNotFoundException.class})
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ModelAndView weaponNotFound(ProductNotFoundException pnfe){
        ModelAndView modelAndView = new ModelAndView("weapon-not-found");
        modelAndView.addObject("weaponId",pnfe.getId());
        return modelAndView;
    }
}
