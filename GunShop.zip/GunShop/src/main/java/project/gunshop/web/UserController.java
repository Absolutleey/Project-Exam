package project.gunshop.web;

import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import project.gunshop.model.enums.GunType;
import project.gunshop.model.dto.UserRegisterDTO;
import project.gunshop.service.UserService;
import project.gunshop.service.WeaponService;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
@RequestMapping("/user")
public class UserController {

    private final UserService userService;
    private final WeaponService weaponService;


    public UserController(UserService userService, WeaponService weaponService1) {
        this.userService = userService;

        this.weaponService = weaponService1;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }


    @GetMapping("/register")
    public String register(Model model) {
        if (!model.containsAttribute("userRegisterDTO")) {
            model.addAttribute("userRegisterDTO", new UserRegisterDTO());
        }
        return "register";
    }


    @PostMapping("/register")
    public String getRegister(@Valid UserRegisterDTO userRegisterDTO,
                              BindingResult bindingResult,
                              RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors() || !userRegisterDTO.getPassword().equals(userRegisterDTO.getConfirmPassword())) {
            redirectAttributes.addFlashAttribute("userRegisterDTO", userRegisterDTO);
            redirectAttributes.addFlashAttribute("org.springframework.validation.userRegisterDTO", bindingResult);
            return "redirect:register";
        }

        userService.register(userRegisterDTO);


        return "redirect:login";
    }



    @GetMapping("logout")
    public String logout(HttpSession httpSession){
        httpSession.invalidate();
        return "redirect:/";
    }

    @PostMapping("/login-error")
    public String onFailedLogin(
            @ModelAttribute(UsernamePasswordAuthenticationFilter.SPRING_SECURITY_FORM_USERNAME_KEY) String username,
            RedirectAttributes redirectAttributes
    ) {

        redirectAttributes.addFlashAttribute(UsernamePasswordAuthenticationFilter.SPRING_SECURITY_FORM_USERNAME_KEY, username);
        redirectAttributes.addFlashAttribute("bad_credentials", true);

        return "redirect:/user/login";
    }

    @GetMapping("/home")
    public String card(Model model) {

        model.addAttribute("total",this.weaponService.getTotalSum());
        model.addAttribute("pistol", this.weaponService.findAllByType(GunType.PISTOL));
        model.addAttribute("shotgun", this.weaponService.findAllByType(GunType.SHOTGUN));
        model.addAttribute("machine_gun", this.weaponService.findAllByType(GunType.MACHINE_GUN));
        model.addAttribute("rifle", this.weaponService.findAllByType(GunType.RIFLE));
        return "home";
    }

    @GetMapping("/buy/{id}")
    public String buyById(@PathVariable Long id){
        weaponService.buyById(id);
        return "redirect:home";
    }

    @GetMapping("/buy/all")
    public String buyAll(){
        weaponService.buyAll();
        return "redirect:home";
    }


}
