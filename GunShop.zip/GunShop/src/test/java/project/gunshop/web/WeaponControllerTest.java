package project.gunshop.web;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.servlet.ModelAndView;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class WeaponControllerTest {

    @Autowired
    private MockMvc mockMvc;


//    @Test
//    void testWeaponAddPageView() throws Exception {
//        mockMvc.perform(get("/weapon/add"))
//                .andExpect(status().is3xxRedirection())
//                .andExpect(view().name("weapon-add"));
//
//    }

//    @Test
//    void testAddWeapon () throws Exception {
//        mockMvc.perform(post("/weapon/add")
//                .param("model","ruger")
//                .param("caliber","2.3")
//                .param("manufacture","2001-01-01")
//                .param("price","2000")
//                .param("type","PISTOL"))
//                .andExpect(status().is4xxClientError())
//                .andExpect(redirectedUrl("/add"));
//
//    }
}
