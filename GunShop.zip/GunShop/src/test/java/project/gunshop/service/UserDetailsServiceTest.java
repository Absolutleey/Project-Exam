package project.gunshop.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import project.gunshop.model.User;
import project.gunshop.model.enums.UserRoleEnum;
import project.gunshop.model.service.AppUserDetailsService;
import project.gunshop.repository.UserRepository;

import java.util.Collection;
import java.util.Iterator;
import java.util.Optional;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UserDetailsServiceTest {

    @Mock
    private UserRepository mockUserRepo;

    private AppUserDetailsService test;

    @BeforeEach
    void setUp() {
        test = new AppUserDetailsService(mockUserRepo);
    }

    @Test
    void LoadUserByUserName_UserExist() {
        User user = new User();
        user.setUsername("Gogo");
        user.setEmail("gogo@abv.bg");
        user.setPassword("1234!@#$");
        user.setUserRole(UserRoleEnum.CUSTOMER);

        when(mockUserRepo.findByUsername(user.getUsername()))
                .thenReturn(Optional.of(user));

        UserDetails userDetails =
                test.loadUserByUsername(user.getUsername());

        Assertions.assertEquals(user.getUsername(),userDetails.getUsername());
        Assertions.assertEquals(user.getPassword(),userDetails.getPassword());

       var authorities = userDetails.getAuthorities();

        Assertions.assertEquals(1,authorities.size());

       var iterator = authorities.iterator();

        Assertions.assertEquals("ROLE_" + UserRoleEnum.CUSTOMER,iterator.next().getAuthority());
    }
}
